"""Count arXiv preprints per year matching a phrase (free arXiv API)."""
import time
import requests
import xml.etree.ElementTree as ET

API = "https://export.arxiv.org/api/query"
NS = {"os": "http://a9.com/-/spec/opensearch/1.1/"}

def count_for_year(phrase, year):
    query = (f'all:"{phrase}" AND submittedDate:'
             f'[{year}01010000 TO {year}12312359]')
    params = {"search_query": query, "max_results": 0}
    r = requests.get(API, params=params, timeout=30)
    r.raise_for_status()
    root = ET.fromstring(r.content)
    return int(root.find("os:totalResults", NS).text)

phrase = "federated learning intrusion detection"
for year in range(2018, 2026):
    n = count_for_year(phrase, year)
    print(f"{year}: {n:5d} " + "#" * min(n // 5, 60))
    time.sleep(3)   # arXiv asks for at least 3 seconds between requests
