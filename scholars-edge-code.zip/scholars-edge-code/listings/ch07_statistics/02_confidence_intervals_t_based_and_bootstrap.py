import numpy as np
from scipy import stats

acc = np.array([0.962, 0.958, 0.971, 0.966, 0.960, 0.969, 0.964, 0.957, 0.968, 0.963])

# Classical t-based 95% CI for the mean
mean, se = acc.mean(), stats.sem(acc)
lo, hi = stats.t.interval(0.95, df=len(acc) - 1, loc=mean, scale=se)
print(f"Mean accuracy = {mean:.4f}, 95% CI [{lo:.4f}, {hi:.4f}]")

# Bootstrap 95% CI: resample with replacement, no normality assumption
rng = np.random.default_rng(42)
boot = [rng.choice(acc, size=len(acc), replace=True).mean() for _ in range(10_000)]
b_lo, b_hi = np.percentile(boot, [2.5, 97.5])
print(f"Bootstrap 95% CI [{b_lo:.4f}, {b_hi:.4f}]")
