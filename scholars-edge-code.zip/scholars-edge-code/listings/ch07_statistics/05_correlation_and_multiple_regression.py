import pandas as pd
from scipy import stats
import statsmodels.formula.api as smf

df = pd.read_csv("phishing_study.csv")

r, p = stats.pearsonr(df["training_hours"], df["click_rate"])
rho, p_s = stats.spearmanr(df["training_hours"], df["click_rate"])
print(f"Pearson r = {r:.3f} (p = {p:.4f}); Spearman rho = {rho:.3f} (p = {p_s:.4f})")

# Multiple linear regression with a categorical control variable
model = smf.ols("click_rate ~ training_hours + years_experience + C(department)",
                data=df).fit()
print(model.summary())
print(model.conf_int().round(4))   # 95% CIs for every coefficient
