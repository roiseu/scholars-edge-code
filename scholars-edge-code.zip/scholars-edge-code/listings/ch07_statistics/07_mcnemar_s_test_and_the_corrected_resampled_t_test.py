import numpy as np
from scipy import stats
from statsmodels.stats.contingency_tables import mcnemar

# (1) McNemar: two models evaluated on the same test set
# Assumes pred_a, pred_b (each model's predictions) and y_test (true labels) already exist
a_ok = (pred_a == y_test)
b_ok = (pred_b == y_test)
table = [[np.sum(a_ok & b_ok),  np.sum(a_ok & ~b_ok)],
         [np.sum(~a_ok & b_ok), np.sum(~a_ok & ~b_ok)]]
res = mcnemar(table, exact=False, correction=True)  # use exact=True if few disagreements
print(f"McNemar chi2 = {res.statistic:.3f}, p = {res.pvalue:.4f}")

# (2) Corrected resampled t-test for k-fold cross-validation scores
def corrected_resampled_ttest(diffs, n_train, n_test):
    """diffs: per-fold score differences (model B minus model A)."""
    d = np.asarray(diffs)
    k = len(d)
    t = d.mean() / np.sqrt((1 / k + n_test / n_train) * d.var(ddof=1))
    p = 2 * stats.t.sf(abs(t), df=k - 1)
    return t, p

fold_diffs = [0.012, 0.009, 0.015, 0.011, 0.008]
t, p = corrected_resampled_ttest(fold_diffs, n_train=80_000, n_test=20_000)
print(f"Corrected t = {t:.3f}, p = {p:.4f}")
