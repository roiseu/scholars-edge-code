import numpy as np
import pandas as pd
from scipy import stats

df = pd.read_csv("model_results.csv")
a = df.loc[df["method"] == "baseline", "accuracy"].to_numpy()
b = df.loc[df["method"] == "proposed", "accuracy"].to_numpy()

for name, g in [("Baseline", a), ("Proposed", b)]:
    print(f"{name}: mean={g.mean():.4f}, SD={g.std(ddof=1):.4f}, n={len(g)}")

# Welch's t-test (recommended default: does not assume equal variances)
t, p = stats.ttest_ind(b, a, equal_var=False)
# Non-parametric check
u, p_u = stats.mannwhitneyu(b, a, alternative="two-sided")

# Mean difference with Welch 95% confidence interval
va, vb = a.var(ddof=1) / len(a), b.var(ddof=1) / len(b)
diff, se = b.mean() - a.mean(), np.sqrt(va + vb)
dof = (va + vb) ** 2 / (va ** 2 / (len(a) - 1) + vb ** 2 / (len(b) - 1))
t_crit = stats.t.ppf(0.975, dof)
ci = (diff - t_crit * se, diff + t_crit * se)

# Cohen's d with pooled standard deviation
sp = np.sqrt(((len(a) - 1) * a.var(ddof=1) + (len(b) - 1) * b.var(ddof=1))
             / (len(a) + len(b) - 2))
d = diff / sp

print(f"Welch t = {t:.3f}, p = {p:.4f}")
print(f"Mann-Whitney U = {u:.1f}, p = {p_u:.4f}")
print(f"Mean difference = {diff:.4f}, 95% CI [{ci[0]:.4f}, {ci[1]:.4f}]")
print(f"Cohen's d = {d:.3f}")
