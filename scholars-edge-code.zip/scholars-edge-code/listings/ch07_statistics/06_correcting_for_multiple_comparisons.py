import numpy as np
from statsmodels.stats.multitest import multipletests

pvals = [0.001, 0.012, 0.028, 0.045, 0.200]
for method in ["bonferroni", "holm", "fdr_bh"]:
    reject, p_adj, _, _ = multipletests(pvals, alpha=0.05, method=method)
    print(f"{method:11s} adjusted={np.round(p_adj, 3)}  significant={reject.sum()}")
# Bonferroni keeps 1 result, Holm keeps 2, Benjamini-Hochberg keeps 3
