import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy import stats

df = pd.read_csv("latency_measurements.csv")
x = df["latency_ms"].dropna()

print(f"n = {len(x)}")
print(f"mean = {x.mean():.2f}, median = {x.median():.2f}")
print(f"SD = {x.std(ddof=1):.2f}, IQR = {x.quantile(0.75) - x.quantile(0.25):.2f}")
print(f"skewness = {stats.skew(x):.2f}")

# Visual checks are more informative than a single normality test
fig, axes = plt.subplots(1, 2, figsize=(10, 4))
axes[0].hist(x, bins=30, color="#14304F", alpha=0.8)
axes[0].set_title("Histogram")
stats.probplot(x, dist="norm", plot=axes[1])
axes[1].set_title("Normal Q-Q plot")
plt.tight_layout()
plt.savefig("latency_distribution.png", dpi=300)
