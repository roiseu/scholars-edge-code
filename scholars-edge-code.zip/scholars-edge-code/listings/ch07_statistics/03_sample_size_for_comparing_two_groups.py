import math
from statsmodels.stats.power import TTestIndPower

analysis = TTestIndPower()
for d in [0.2, 0.5, 0.8]:
    n = analysis.solve_power(effect_size=d, alpha=0.05, power=0.80,
                             alternative="two-sided")
    print(f"Effect size d = {d}: {math.ceil(n)} participants per group")
# Expected output: about 394, 64, and 26 per group
